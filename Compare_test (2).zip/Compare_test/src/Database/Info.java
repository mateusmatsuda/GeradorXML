package Database;

import java.sql.ResultSet;

import Database.OracleConnection;

public class Info {
	private int COD_PRODUTO;
	private String VERSAO;
	private String TABLE;
	private String VIEW;
	private String SEQUENCE;
	private String PROCEDURE;
	private String FUNCTION;
	private String PACKAGE;
	private String PACKAGE_BODY;
	private String TRIGGER;

	/**
	 * 
	 */
	public Info() {
	}

	/**
	 * 
	 * @return
	 */
	public String getTABLES() {
		return TABLE;
	}

	/**
	 * 
	 * @param TABLES
	 */
	public void setTABLES(String TABLES) {
		this.TABLE = TABLES;
	}

	/**
	 * 
	 * @return
	 */
	public String getVIEWS() {
		return VIEW;
	}

	/**
	 * 
	 * @param VIEWS
	 */
	public void setVIEWS(String VIEW) {
		this.VIEW = VIEW;
	}

	/**
	 * 
	 * @return
	 */
	public String getSEQUENCE() {
		return SEQUENCE;
	}

	/**
	 * 
	 * @param SEQUENCES
	 */
	public void setSEQUENCES(String SEQUENCE) {
		this.SEQUENCE = SEQUENCE;
	}

	/**
	 * 
	 * @return
	 */
	public String getPROCEDURE() {
		return PROCEDURE;
	}

	/**
	 * 
	 * @param PROCEDURE
	 */
	public void setPROCEDURE(String PROCEDURE) {
		this.PROCEDURE = PROCEDURE;
	}

	/**
	 * 
	 * @return
	 */
	public String getFUNCTION() {
		return FUNCTION;
	}

	/**
	 * 
	 * @param FUNCTION
	 */
	public void setFUNCTION(String FUNCTION) {
		this.FUNCTION = FUNCTION;
	}

	/**
	 * 
	 * @return
	 */
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * 
	 * @param PACKAGE
	 */
	public void setPACKAGE(String PACKAGE) {
		this.PACKAGE = PACKAGE;
	}

	/**
	 * 
	 * @return
	 */
	public String getPACKAGE_BODY() {
		return PACKAGE_BODY;
	}

	/**
	 * 
	 * @param PACKAGE_BODY
	 */
	public void setPACKAGE_BODY(String PACKAGE_BODY) {
		this.PACKAGE_BODY = PACKAGE_BODY;
	}

	/**
	 * 
	 * @return
	 */
	public String getTRIGGER() {
		return TRIGGER;
	}

	/**
	 * 
	 * @param TRIGGER
	 */
	public void setTRIGGER(String TRIGGER) {
		this.TRIGGER = TRIGGER;
	}

	/**
	 * Retorna o C�digo do Produto;
	 * 
	 * @return int
	 */
	public int getCOD_PRODUTO() {
		return COD_PRODUTO;
	}

	/**
	 * Seta o c�digo do Produto;
	 * 
	 * @param cOD_PRODUTO
	 */
	public void setCOD_PRODUTO(int COD_PRODUTO) {
		this.COD_PRODUTO = COD_PRODUTO;
	}

	/**
	 * Retorna a vers�o da compara��o;
	 * 
	 * @return
	 */
	public String getVERSAO() {
		return VERSAO;
	}

	/**
	 * Seta a vers�o da compara��o;
	 * 
	 * @param VERSAO
	 */
	public void setVERSAO(String VERSAO) {
		this.VERSAO = VERSAO;
	}

	/**
	 * Extrai um resumo da base de dados.
	 */
	public void ObjectsRelat(OracleConnection con) {
		ResultSet rs;
		try {
			con.Connect();
			rs = con.Query("SELECT COUNT(1) AS TABLES FROM USER_TABLES");
			if (rs.next()) {
				this.setTABLES(rs.getString("TABLES"));
			}
			rs = con.Query("SELECT COUNT(1) AS VIEWS FROM USER_VIEWS");
			if (rs.next()) {
				this.setVIEWS(rs.getString("VIEWS"));
			}
			rs = con.Query("SELECT COUNT(1) AS SEQUENCES FROM USER_SEQUENCES");
			if (rs.next()) {
				this.setSEQUENCES(rs.getString("SEQUENCES"));
			}
			rs = con.Query("SELECT COUNT(1) AS PROCEDURE FROM USER_OBJECTS WHERE OBJECT_TYPE = 'PROCEDURE'");
			if (rs.next()) {
				this.setPROCEDURE(rs.getString("PROCEDURE"));
			}
			rs = con.Query("SELECT COUNT(1) AS FUNCTION FROM USER_OBJECTS WHERE OBJECT_TYPE = 'FUNCTION'");
			if (rs.next()) {
				this.setFUNCTION(rs.getString("FUNCTION"));
			}
			rs = con.Query("SELECT COUNT(1) AS PACKAGE FROM USER_OBJECTS WHERE OBJECT_TYPE = 'PACKAGE'");
			if (rs.next()) {
				this.setPACKAGE(rs.getString("PACKAGE"));
			}
			rs = con.Query("SELECT COUNT(1) AS PACKAGEBODY FROM USER_OBJECTS WHERE OBJECT_TYPE = 'PACKAGE BODY'");
			if (rs.next()) {
				this.setPACKAGE_BODY(rs.getString("PACKAGEBODY"));
			}
			rs = con.Query("SELECT COUNT(1) AS TRIGGERS FROM USER_OBJECTS WHERE OBJECT_TYPE = 'TRIGGER'");
			if (rs.next()) {
				this.setTRIGGER(rs.getString("TRIGGERS"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.Close();
		}
	}
}
