package Database;


public class Usuario {
	// Espa�o para Vari�veis
	private String _nome_sistema;
	private String	_usuario;
	private String	_password;
	private String _cod_sistema;
	private String _cod_versao;
	// Fim do Espa�o para Vari�veis
	//
	// Construtor da Classe
	/**
	 * 
	 */
	public Usuario() {
	}

	/**
	 * 
	 * @return
	 */
	public String get_usuario() {
		return _usuario;
	}

	/**
	 * 
	 * @param _usuario
	 */
	public void set_usuario(String _usuario) {
		this._usuario = _usuario;
	}

	/**
	 * 
	 * @return
	 */
	public String get_password() {

		return _password;
	}

	/**
	 * 
	 * @param _password
	 */
	public void set_password(String _password) {
		this._password = _password;
	}

	/**
	 * 
	 * @return
	 */
	public String get_cod_sistema() {
		return _cod_sistema;
	}

	/**
	 * 
	 * @param _cod_sistema
	 */
	public void set_cod_sistema(String _cod_sistema) {
		this._cod_sistema = _cod_sistema;
	}

	/**
	 * 
	 * @return
	 */
	public String get_cod_versao() {
		return _cod_versao;
	}

	/**
	 * 
	 * @param _cod_versao
	 */
	public void set_cod_versao(String _cod_versao) {
		this._cod_versao = _cod_versao;
	}

	
	/**
	 * 
	 * @return
	 */
	public String get_nome_sistema() {
		return _nome_sistema;
	}
	
	/**
	 * 
	 * @param _nome_sistema
	 */

	public void set_nome_sistema(String _nome_sistema) {
		this._nome_sistema = _nome_sistema;
	}
	
	
}
