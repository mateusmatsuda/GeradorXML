package Database;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import Entities.Objeto;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.driver.OracleDriver;

/**
 * Classe de conex�o com o banco de dados Oracle.
 */
public class OracleConnection {

	private Connection _conn;
	private String stringUsuario;
	private String stringSenha;
	private String stringTns;
	private OraclePreparedStatement _statement_st;

	/**
	 * Efetua a conex�o
	 * 
	 * @throws Exception
	 */

	//
	public String pegarVersao() throws SQLException {

		String v2 = null;
		ResultSet ver = this
				.Query("select cod_versao from sfw_sistema_versao where valido = 'S' and cod_sistema = '0'");

		while (ver.next()) {
			v2 = ver.getString("cod_versao");
		}
		System.out.println(v2);
		return v2;
	}
	//

	public void Connect() throws Exception {
		Properties v_properties_prop;

		v_properties_prop = new Properties();
		v_properties_prop.put("user", this.getUsuario());
		v_properties_prop.put("password", this.getSenha());

		DriverManager.registerDriver(new OracleDriver());

		this._conn = DriverManager.getConnection(this.getURL(), v_properties_prop);
	}

	/**
	 * Fecha conex�o com Oracle
	 * 
	 * @throws SQLException
	 */
	public void CloseStatement() {
		try {
			if (this._statement_st != null) {
				this._statement_st.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Fecha conex�o com Oracle
	 * 
	 * @throws SQLException
	 */
	public void Close() {
		try {
			if (this._conn != null && !this._conn.isClosed()) {
				this._conn.rollback();
				this._conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param Query a ser executada
	 * @return Resultset do select executado
	 * @throws SQLException
	 */
	public ResultSet Query(String query) throws SQLException {
		ResultSet v_resultset_result;

		_statement_st = (OraclePreparedStatement) this._conn.prepareStatement(query);
		v_resultset_result = _statement_st.executeQuery();
		return v_resultset_result;
	}

	/**
	 * 
	 * @param Query a ser executada
	 * @return 0 ou 1
	 * @throws SQLException
	 */
	public int Update(String query) throws SQLException {

		_statement_st = (OraclePreparedStatement) this._conn.prepareStatement(query);
		int i = _statement_st.executeUpdate();

		return i;
	}

	/**
	 * 
	 * @param Query a ser executada
	 * @return 0 ou 1
	 * @throws SQLException
	 */
	public int Insert(String query) throws SQLException {

		_statement_st = (OraclePreparedStatement) this._conn.prepareStatement(query);
		int i = _statement_st.executeUpdate();

		return i;
	}

	/**
	 * 
	 * @param Query a ser executada
	 * @return 0 ou 1
	 * @throws SQLException
	 */
	public int Delete(String query) throws SQLException {

		_statement_st = (OraclePreparedStatement) this._conn.prepareStatement(query);
		int i = _statement_st.executeUpdate();

		return i;
	}

	/**
	 * 
	 * @param procedure  a ser executada
	 * @param Parametros da procedure
	 * @return 0 ou 1
	 * @throws SQLException
	 */

	public int ExecuteProcedure(String procedure, ArrayList<String> Param) throws SQLException {
		String procedureParam = "begin ? := " + procedure + " ";
		procedureParam += "(";
		for (int i = 0; i < Param.size(); i++) {
			procedureParam += "?,";
		}
		procedureParam = procedureParam.substring(0, procedureParam.length() - 1);
		procedureParam += "); end;";
		CallableStatement cs = this._conn.prepareCall("" + procedureParam + "");
		cs.registerOutParameter(1, Types.NUMERIC);
		for (int i = 0; i < Param.size(); i++) {
			if (Param.get(i) instanceof String) {
				cs.setString(i + 2, Param.get(i).toString());
			} else {
				cs.setInt(i + 2, Integer.parseInt(Param.get(i).toString()));
			}
		}
		cs.execute();
		int a = cs.getInt(1);
		return a;
	}

	/**
	 * 
	 * @param p_baseGenerica
	 * @return
	 * @throws SQLException
	 */
	public List<Objeto> returnUsersFromDatabase() throws SQLException {
		Objeto objeto1;

		// Versao versao1;
		List<Objeto> v_list_usuario = new ArrayList<Objeto>();

		ResultSet idmax = this.Query("select max(id_verificacao) from sfw_verific_integridade");
		Integer idm = 0;
		while (idmax.next()) {

			idm = idmax.getInt("max(id_verificacao)");

		}

		ResultSet rs = this.Query("select sfw.s_nome_objeto, sfw.s_owner_objeto, scm.cod_sistema, sfw.s_tipo_objeto, "
				+ " sfw.s_tipo_inconformidade, sfw.s_conteudo_objeto "
				+ " from sfw_verific_integridade_obj sfw, sfw_cm_schema scm " + " where id_verificacao = " + idm
				+ " and sfw.s_owner_objeto = scm.s_schema_owner and sfw.s_tipo_inconformidade != 'A MAIS'"
				+ " and scm.cod_sistema in ('0','2','3','6','9','10','11','21') and "
				+ "s_tipo_objeto in ('FUNCTION','PACKAGE','PACKAGE BODY','VIEW','TRIGGER','PROCEDURE')");

		while (rs.next()) {

			// popula objeto1
			objeto1 = new Objeto();
			objeto1.setNome(rs.getString("s_nome_objeto"));
			objeto1.setCodSistema(rs.getInt("cod_sistema"));
			objeto1.setTipo(rs.getString("s_tipo_objeto"));
			objeto1.setErro(rs.getString("s_tipo_inconformidade"));
	

			String nome = rs.getString("s_nome_objeto");
			String tipo = rs.getString("s_tipo_objeto");
			// System.out.println(nome);

			if (tipo.equals("VIEW")) {
				String codview = "create or replace view as ";
			
				ResultSet codv = this.Query("select TEXT from all_views where view_name = '" + nome + "' "
						+ "and owner = '"+ rs.getString("s_owner_objeto")+"'");
			
				while(codv.next()) {
					

					codview = codview + codv.getString("TEXT");
					
				}
				codv.getStatement().close();
				codview.trim();
				codview = codview + "\n;";
				objeto1.setCodigo(codview);					
				
				

	


			} else {
				ResultSet rscodigo = this
						.Query("select TEXT from all_source where name = '" + nome + "' and owner = '"+
                  rs.getString("s_owner_objeto")+"' and type =  '"+ tipo + "' order by line");

				String cod = "create or replace ";

				while (rscodigo.next()) {
					cod = cod + rscodigo.getString("TEXT");

				}
				rscodigo.getStatement().close();
				cod.trim();
				cod = cod + "\n/";
				objeto1.setCodigo(cod);
			}

			System.out.println("adicionando objeto " +objeto1.getNome() );
			v_list_usuario.add(objeto1);



		}
		rs.getStatement().close();
		return v_list_usuario;

	}

	/**
	 * 
	 * @return a url de conex�o
	 */
	public String getURL() throws Exception, SQLException {

		String v_s_host = "";
		String v_s_tnsping;
		Process p = Runtime.getRuntime().exec("tnsping " + this.getStringTns());
		InputStream stdoutStream = new BufferedInputStream(p.getInputStream());

		StringBuffer buffer = new StringBuffer();
		for (;;) {
			int c = stdoutStream.read();
			if (c == -1) {
				break;
			}
			buffer.append((char) c);
		}
		v_s_tnsping = buffer.toString().toUpperCase();

		stdoutStream.close();

		v_s_tnsping = v_s_tnsping.replaceAll(" ", "");

		v_s_host = v_s_tnsping.substring(v_s_tnsping.indexOf("(DESCRIPTION"), v_s_tnsping.indexOf("OK"));

		return v_s_host = "jdbc:oracle:thin:@" + v_s_host;

	}

	/**
	 * 
	 * @return usu�rio de conex�o
	 */
	public String getUsuario() {
		return stringUsuario;
	}

	/**
	 * 
	 * @param usuario para conex��o
	 */
	public void setUsuario(String usuario) {
		this.stringUsuario = usuario;
	}

	/**
	 * 
	 * @return senha para conex�o
	 */
	public String getSenha() {
		return stringSenha;
	}

	/**
	 * 
	 * @param senha de conex�o
	 */
	public void setSenha(String senha) {
		this.stringSenha = senha;
	}

	/**
	 * 
	 * @return tns para conex�o
	 */
	public String getStringTns() {
		return stringTns;
	}

	/**
	 * 
	 * @param tns para conex�o
	 */
	public void setStringTns(String stringTns) {
		this.stringTns = stringTns;
	}
}
