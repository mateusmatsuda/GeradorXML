package Database;

public class Install {
	public static Usuario _usuario;
	public static String _tns;

	/**
	 * 
	 * @return
	 */
	public static Usuario get_usuario() {
		return _usuario;
	}

	/**
	 * 
	 * @param _usuario
	 */
	public static void set_usuario(Usuario _usuario) {
		Install._usuario = _usuario;
	}

	/**
	 * 
	 * @return
	 */
	public static String get_tns() {
		return _tns;
	}

	/**
	 * 
	 * @param _tns
	 */
	public static void set_tns(String _tns) {
		Install._tns = _tns;
	}
}
