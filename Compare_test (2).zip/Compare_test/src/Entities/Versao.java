package Entities;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class Versao {

	private String id;
	
	private List<Objeto> objetos;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<Objeto> getObjetos() {
		return objetos;
	}

	public void setObjetos(List<Objeto> objetos) {
		this.objetos = objetos;
	}
	
	

	
	 

}
