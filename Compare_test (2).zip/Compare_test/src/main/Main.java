package main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.List;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import Database.Install;
import Database.OracleConnection;
import Entities.Objeto;
import Entities.Versao;

public class Main {

	public static void main(String[] args) throws Exception {
		Objeto objeto1 = new Objeto(); // instancia o objeto vazio na memoria
		Objeto objeto2 = new Objeto();
		String v1 = null;
		List<Objeto> users = null;

		String v_s_usuarioBaseGenerica = "";

		Versao novaVersao = new Versao();

		OracleConnection con = null;

		
		/*
		// get VM argument user from;
				String userFrom = "trmat";

				// get VM argument password from;
				String passFrom = "trmat";

				// get VM argument tns from;
				String tnsFrom = "ora12q01";
		*/
		

		// get VM argument user from;
		String userFrom = System.getProperty("userFrom");

		// get VM argument password from;
		String passFrom = System.getProperty("passFrom");

		// get VM argument tns from;
		String tnsFrom = System.getProperty("tnsFrom");
		
		// check if from user was placed as parameter;
		if (userFrom == null) {
			throw new Exception("VM Parameter -DuserFrom not found!");
		}

		// check if from pass was placed as parameter;
		if (passFrom == null) {
			throw new Exception("VM Parameter -DpassFrom not found!");
		}

		// check if from tns was placed as parameter;
		if (tnsFrom == null) {
			throw new Exception("VM Parameter -DtnsFrom not found!");
		}

		try {
			// add oracle information;
			con = new OracleConnection();
			con.setUsuario(userFrom);
			con.setSenha(passFrom);
			con.setStringTns(tnsFrom);

			// connect into oracle;
			con.Connect();

			v1 = con.pegarVersao();

			novaVersao.setId(v1);

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("ERRO: " + userFrom + "/" + passFrom + "@" + tnsFrom + " -> " + e.getMessage());
		}

		try {

			Install.set_tns(tnsFrom);

			users = con.returnUsersFromDatabase();

			novaVersao.setObjetos(users);

		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}

		XStream xstream = new XStream(new DomDriver());

		xstream.alias("Versao", Versao.class);
		xstream.alias("Objeto", Objeto.class);
		String xml = xstream.toXML(novaVersao);

		xml = xml.replaceAll("&apos;", "'");
		xml = xml.replaceAll("&quot;", "\"");

		System.out.println(xml);
		// String contatosEmXML = xstream.toXML(novaVersao);
		File temp = new File("temp");
		if (!temp.exists()) {
			temp.mkdirs();
		}

		OutputStream os = new FileOutputStream(new File(temp + "\\"+userFrom +"_"+ novaVersao.getId() + ".xml"));
		OutputStreamWriter bw = new OutputStreamWriter(os, "UTF8");

		bw.write(xml);
		bw.flush();
		bw.close();

	}

}
