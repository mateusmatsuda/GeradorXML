package Interfaces;

public interface Objects {
	public boolean equals(Object obj);
}
